// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, implicit_dynamic_list_literal

import 'dart:io';

import 'package:dart_frog/dart_frog.dart';


import '../routes/api/products.dart' as api_products;
import '../routes/api/login.dart' as api_login;
import '../routes/api/index.dart' as api_index;
import '../routes/api/RR/user.dart' as api_r_r_user;

import '../routes/api/RR/_middleware.dart' as api_r_r_middleware;

void main() async {
  final address = InternetAddress.tryParse('') ?? InternetAddress.anyIPv6;
  final port = int.tryParse(Platform.environment['PORT'] ?? '8080') ?? 8080;
  hotReload(() => createServer(address, port));
}

Future<HttpServer> createServer(InternetAddress address, int port) {
  final handler = Cascade().add(buildRootHandler()).handler;
  return serve(handler, address, port);
}

Handler buildRootHandler() {
  final pipeline = const Pipeline();
  final router = Router()
    ..mount('/api/RR', (context) => buildApiRRHandler()(context))
    ..mount('/api', (context) => buildApiHandler()(context));
  return pipeline.addHandler(router);
}

Handler buildApiRRHandler() {
  final pipeline = const Pipeline().addMiddleware(api_r_r_middleware.middleware);
  final router = Router()
    ..all('/user', (context) => api_r_r_user.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildApiHandler() {
  final pipeline = const Pipeline();
  final router = Router()
    ..all('/products', (context) => api_products.onRequest(context,))..all('/login', (context) => api_login.onRequest(context,))..all('/', (context) => api_index.onRequest(context,));
  return pipeline.addHandler(router);
}

