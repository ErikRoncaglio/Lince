import 'dart:async';
import 'package:dart_frog/dart_frog.dart';
import 'package:http/http.dart' as http;
import '../../security/token.dart';

/// Definição do endpoint que receberá a requisição http desse endpoint
Future<Response> onRequest(RequestContext context) async {
  return switch (context.request.method) {
    HttpMethod.post => await _handlePost(context),
    _ => Response(
        body: 'Método não suportado',
        statusCode: 405,
        headers: {
          "Access-Control-Allow-Origin": "*",
        },
      ),
  };
}

// Ação executada ao receber requisição http post
Future<Response> _handlePost(RequestContext context) async {
  final body = await context.request.json();
  print(body);
  final loginRequest = LoginRequest.fromJson(body);
  print(loginRequest.password);
  print(loginRequest.login);
  try {
    print("entrou no try");

    print(authenticate(loginRequest).toJson());

    return Response.json(
      body: authenticate(loginRequest).toJson(),
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
    );
  } catch (e) {
    print("caiu no catch");
    return Response.json(
      statusCode: 403,
      body: {'status': 'OK'},
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
    );
  }
}
