import 'package:dart_frog/dart_frog.dart';

import '../../security/token.dart';

// Esse endpoint só é acessível para usuários autenticados através um token
Future<Response> onRequest(RequestContext context) async {
  return Response(
    body: 'ok', headers: {
    "Access-Control-Allow-Origin": "*",
  },
  );
}
