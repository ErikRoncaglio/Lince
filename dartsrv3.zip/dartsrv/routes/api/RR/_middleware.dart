import 'package:dart_frog/dart_frog.dart';
import 'package:dart_frog_auth/dart_frog_auth.dart';

import '../../../security/token.dart';





/// Middleware que validará se as requisições feitas para as rotas /RR/* estão
/// devidamente autenticadas
Handler middleware(Handler handler) {
print('chegou no middleware');
  return handler
      // Log all the received requests
      .use(requestLogger())
      // Check the token in the request
      .use(
        bearerAuthentication<AuthContext>(
          authenticator: _handleToken,
        ),
      );
}

Future<AuthContext> _handleToken(RequestContext context, String token) async {
  // Validar se o token recebido é valido
  print('chamou o _handle');
  final (tokenID, login, expiresAt) = checkToken(token);
print(tokenID);
  print(login);
  print(expiresAt);
  // Retorna o contexto de autorização
  return AuthContext(
    tokenID,
    login,
    expiresAt,
  );
}
