import 'package:dart_frog/dart_frog.dart';

import '../../../security/token.dart';


// http.get(...)/RR/user
//post (json)

// Esse endpoint só é acessível para usuários autenticados através um token
Future<Response> onRequest(RequestContext context) async {
  print("entrou na classe user");
  if (context.request.method != HttpMethod.get) {

    print("aaaaaaaaaaaaaaaaaa");
    return Response(
      body: 'Método não suportado',
      statusCode: 405,
      headers: {
        'Access-Control-Allow-Origin': '*',
      },
    );
  }

  return await _handleGet(context);
}

Future<Response> _handleGet(RequestContext context) async {
  // Carregar dados do usuário autenticado
  final authContext = context.read<AuthContext>();
  print("autentificação");
  return Response(
    statusCode: 200,
    body: 'Bem-vindo, ${authContext.login}',
    headers: {
      'Access-Control-Allow-Origin': '*',
    },
  );
}
