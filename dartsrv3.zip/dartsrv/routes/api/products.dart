import 'package:dart_frog/dart_frog.dart';


import '../../src/Control/Product/productDAO.dart';
import '../../src/model/product.dart';


Future<Response> onRequest(RequestContext context) async {
  if (context.request.method == HttpMethod.get) {
    return await _listP(context);
  }else if(context.request.method == HttpMethod.post){
    return await _insertP(context);
  }

  return Response(
    body: 'Método não suportado',
    statusCode: 405,
    headers: {
      "Access-Control-Allow-Origin": "*",
    },
  );

}

Future<Response> _listP(RequestContext context) async {
  try {
    print("entrou no try");

    // var Pdao = ProductDAO();
    // final list = await Pdao.listProduct();


    Product p= Product(1, 'name', 'additionalInformation', 'barcode', 'brand', 'type',
        'picture', 2);
    Product a= Product(1, 'name', 'additionalInformation', 'barcode', 'brand', 'type',
        'picture', 2);
    print(a.tojson());
    Product b= Product(1, 'name', 'additionalInformation', 'barcode', 'brand', 'type',
        'picture', 2);
    List<Map<String, dynamic>> list = [];
    list.add(p.tojson());
    list.add(b.tojson());
    list.add(a.tojson());

print(list.toString());

    return Response.json(
      body: list,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
    );
  } catch (e) {
    print("caiu no catch");
    return Response.json(
      statusCode: 403,
      body: {'status': 'OK'},
      headers: {
        'Access-Control-Allow-Origin': '*',
      },
    );
  }
}

Future<Response> _insertP(RequestContext context) async {
  final json = await context.request.json();
  print(json.body);
  Product p= Product.fromJson(json);
  ProductDAO dao = ProductDAO();

  dao.insertProduct(p);

  return Response(statusCode: 200, headers: {
    "Access-Control-Allow-Origin": "*",
  },);
}

//backend completo
// import 'package:dart_frog/dart_frog.dart';
// import '../../src/Control/Product/productDAO.dart';
// import '../../src/model/product.dart';
//
// Future<Response> onRequest(RequestContext context) async {
//   if (context.request.method == HttpMethod.get) {
//     return await _listProducts(context);
//   } else if (context.request.method == HttpMethod.post) {
//     return await _insertProduct(context);
//   } else if (context.request.method == HttpMethod.put) {
//     return await _updateProduct(context);
//   } else if (context.request.method == HttpMethod.delete) {
//     return await _deleteProduct(context);
//   }
//
//   return Response(
//     body: 'Método não suportado',
//     statusCode: 405,
//     headers: {
//       "Access-Control-Allow-Origin": "*",
//     },
//   );
// }
//
// Future<Response> _listProducts(RequestContext context) async {
//   try {
//     Product p = Product(1, 'name', 'additionalInformation', 'barcode', 'brand', 'type', 'picture', 2);
//     Product a = Product(2, 'name2', 'additionalInformation2', 'barcode2', 'brand2', 'type2', 'picture2', 3);
//     Product b = Product(3, 'name3', 'additionalInformation3', 'barcode3', 'brand3', 'type3', 'picture3', 4);
//
//     List<Map<String, dynamic>> list = [p.tojson(), a.tojson(), b.tojson()];
//
//     return Response.json(
//       body: list,
//       headers: {
//         "Access-Control-Allow-Origin": "*",
//       },
//     );
//   } catch (e) {
//     return Response.json(
//       statusCode: 500,
//       body: {'error': 'Erro interno do servidor'},
//       headers: {
//         'Access-Control-Allow-Origin': '*',
//       },
//     );
//   }
// }
//
// Future<Response> _insertProduct(RequestContext context) async {
//   final json = await context.request.json();
//   Product product = Product.fromJson(json);
//   ProductDAO dao = ProductDAO();
//   dao.insertProduct(product);
//
//   return Response(
//     statusCode: 200,
//     body: {'message': 'Produto adicionado com sucesso'},
//     headers: {"Access-Control-Allow-Origin": "*"},
//   );
// }
//
// Future<Response> _updateProduct(RequestContext context) async {
//   final json = await context.request.json();
//   Product product = Product.fromJson(json);
//   ProductDAO dao = ProductDAO();
//   dao.updateProduct(product);
//
//   return Response(
//     statusCode: 200,
//     body: {'message': 'Produto atualizado com sucesso'},
//     headers: {"Access-Control-Allow-Origin": "*"},
//   );
// }
//
// Future<Response> _deleteProduct(RequestContext context) async {
//   final productId = int.parse(context.request.uri.pathSegments.last);
//   ProductDAO dao = ProductDAO();
//   dao.deleteProduct(productId);
//
//   return Response(
//     statusCode: 200,
//     body: {'message': 'Produto excluído com sucesso'},
//     headers: {"Access-Control-Allow-Origin": "*"},
//   );
// }
