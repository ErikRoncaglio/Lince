# dartsrv

Aplicação de backend na linguagem Dart, utilizando o framework [Dart Frog](https://dartfrog.vgv.dev/).

### Comandos

Antes de começar a trabalhar com esse backend, é necessário configurar o framework **Dart Frog**, executando o comando a
seguir:
> dart pub global activate dart_frog_cli

Com o framework instalado, você poderá executar a aplicação em modo desenvolvimento, através do comando:
> dart_frog dev

Para construir a versão de produção, utilize o comando a seguir:
> dart_frog build

O framework também possui métodos para simplificar a criação de recursos, por exemplo:

- Criar nova rota/endpoint: `dart_frog new route "/rota"`
- Criar novo middleware: `dart_frog new middleware "/rota"`

Requisitos técnicos
• Implementar o painel web da aplicação utilizando o framework Flutter.
• Implementar o backend da aplicação, utilizando o framework Dart Frog (projeto base no GitLab).
• Utilizar a biblioteca go_router para controlar as rotas do painel web.
• Utilizar a biblioteca sqflite para gerenciar os dados no backend da aplicação.
//• Utilizar a biblioteca shared_preferences para gerenciar detalhes no painel web da aplicação:
//o Idioma da aplicação (português ou inglês).
//o Tema da aplicação (claro, escuro, automático).
• Permitir o upload de imagens dos produtos através do painel web, utilizando o plugin image_picker.
• Utilizar a biblioteca provider para realizar o gerenciamento de estados do painel web.
• O código-fonte de ambas as aplicações deve ser escrito em inglês, manter consistência na nomeação
de classes, parâmetros e variáveis.
• Para o painel web, utilizar o padrão de análise estática de código através do plugin flutter_lints. O
código deve ser formatado corretamente e ser limpo de erros e alertas. Utilizar as regras de análise do
arquivo analysis_options.yaml.
• Para o backend, deve-se aderir as regras já definidas no analysis_options.yaml do projeto base.
• Para geração do relatório de produtos em PDF, deve ser utilizada a biblioteca pdf.
• Para a internacionalização, deve ser utilizada a biblioteca intl.
• Toda comunicação entre o painel web e backend deve ser realizada através do protocolo HTTP, no
formato json.
• O painel web precisa ser responsivo (adaptar-se de maneira adequada, a diferentes tamanhos de tela).
• O acesso ao painel web deverá ser acessível mediante ao fornecimento de credenciais corretas em
uma tela de login. O webservice de login já está implementado no projeto base fornecido.
• Todos os endpoints do backend, devem ser prefixados com “/api”. Nesse padrão, um endpoint de
exemplo ficaria: “/api/exemplo”.