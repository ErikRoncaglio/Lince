// ignore_for_file: avoid_dynamic_calls

import 'dart:convert';
import 'package:intl/intl.dart';

// Para esse programa de exemplo, o login é um valor fixo (apenas p/ demonstração)
const _userLogin = 'erik';

// Para esse programa de exemplo, a senha é um valor fixo (apenas p/ demonstração)
const _userPassword = 'erik123';

// Formatar data e hora
final _dateTimeFormat = DateFormat('yyyy-MM-dd HH:mm:ss');

// Definição do tempo de duração do tokens de login
const _tokenDuration = Duration(
  days: 1,
);

// Contador para gerar tokens
var _tokenCount = 1;

/// Definição dos dados recebidos para ação de login
class LoginRequest {
  /// Decodificar credenciais a partir de um json
  LoginRequest.fromJson(dynamic json)
      : login = json['login'] as String,
        password = json['password'] as String;

  /// Login recebido para validar a permissão de acesso do usuário
  final String login;

  /// Senha recebida para validar a permissão de acesso do usuário
  final String password;
}

/// Resposta a gerada em casos de logins bem sucedidos
class LoginResponse {
  /// Construtor padrão para login bem sucedido
  const LoginResponse(
    this.token,
    this.expiresAt,
  );

  /// Token de acesso do usuário
  final String token;

  /// Data e hora de expiração do token
  final DateTime expiresAt;

  /// Codifica essa resposta em formato json
  Map<String, dynamic> toJson() => {
        'token': token,
        'expiresAt': _dateTimeFormat.format(expiresAt),
      };
}

/// Contem as informações do usuário autenticado
class AuthContext {
  /// Construtor padrão
  const AuthContext(
    this.tokenID,
    this.login,
    this.expiresAt,
  );

  /// ID do token
  final int tokenID;

  /// Login do usuário autenticado
  final String login;

  /// Data e hora de expiração do token
  final DateTime expiresAt;
}

/// Implementação ingenua de geração de token de login (para demonstração).
/// This method throws [Exception] if credentials provided do not match the
/// application credentials.
LoginResponse authenticate(LoginRequest request) {
  if (request.login != _userLogin || request.password != _userPassword) {

    throw Exception('Credenciais inválidas');
  }

  final tokenID = _tokenCount;
  final expiresAt = DateTime.now().add(_tokenDuration);
  final token = base64Encode('${request.login}.$expiresAt.$tokenID'.codeUnits);

  // Incrementar id do token
  _tokenCount++;

  return LoginResponse(token, expiresAt);
}

/// Verifica se o token recebido é valido
(int, String, DateTime) checkToken(String token) {
  print("entrou no checktoken");
  try {
    final tokenData = String.fromCharCodes(base64Decode(token));
    final splitToken = tokenData.split('.');
    final login = splitToken[0];
    final expiresAt = _dateTimeFormat.parse(splitToken[1]);

    // Decodifica o id do token
    final tokenID = int.parse(splitToken[2]);
    final now = DateTime.now();

    // Verificar se o token está expirado
    if (!now.isBefore(expiresAt)) {
      throw Exception('Token expirado');
    }

    return (tokenID, login, expiresAt);
  } catch (_) {
    rethrow;
  }
}
