class Product {
  int productId;
  String name;
  String additionalInformation;
  String barcode;
  String brand;
  String type;
  String picture;
  double price;

  Product(this.productId, this.name, this.additionalInformation, this.barcode, this.brand,
      this.type, this.picture, this.price);

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
        json["productId"],
        json['name'],
        json['additionalInformation'],
        json['barcode'],
        json['brand'],
        json['type'],
        json['picture'],
        json['price']);
  }

  Map<String, dynamic> tojson() => {
    'productId': this.productId,
    'name': this.name,
    'additionalInformation': this.additionalInformation,
    'barcode': this.barcode,
    'brand': this.brand,
    'type': this.type,
    'picture': this.picture,
    'price': this.price
  };
}
