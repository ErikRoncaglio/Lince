import 'product.dart';

class Variant {
  int variantId;
  Product product;
  String variantDescription;
  String variantBarcode;

  Variant(this.variantId, this.product, this.variantDescription, this.variantBarcode);
}
