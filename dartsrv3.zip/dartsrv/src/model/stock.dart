import 'product.dart';
import 'variant.dart';

class Stock {
  int stockId;
  Product product;
  //List<Variant>
  Variant variants;
  String batch;
  String manufacturingDate;
  String expirationDate;
  int quantityUnits;
  int originalQuantityUnits;
  double quantityWeight;
  double originalQuantityWeight;
  double priceAcquire;

  Stock(this.stockId,
      this.product,
      this.variants,
      this.batch,
      this.manufacturingDate,
      this.expirationDate,
      this.quantityUnits,
      this.originalQuantityUnits,
      this.quantityWeight,
      this.originalQuantityWeight,
      this.priceAcquire);
}

enum TypesProducts {
  perishableFoods,
  nonPerishableFood,
  housewares,
  stationery
}
