import '../../model/stock.dart';
import '../Conexao/conection.dart';
import 'iStockDAO.dart';

class StockDAO implements IStockDAO {
  @override
  Future<bool> cleanStock() async {
    // TODO: implement cleanStock
    throw UnimplementedError();
  }

  @override
  Future<void> insertStock(Stock stock) async {
    final database = await getDatabase();
    final map = TableStock.toMap(stock);

    await database.insert(TableStock.tableName, map);

    return;
  }

  @override
  Future<List<Stock>> listStock() async {
    final database = await getDatabase();
    final List<Map<String, dynamic>> result =
        await database.query(TableStock.tableName);

    var list = <Stock>[];

    for (final item in result) {
      list.add(Stock(
          item[TableStock.id],
          item[TableStock.product],
          item[TableStock.variants] ?? null,
          item[TableStock.batch],
          item[TableStock.manufacturingDate],
          item[TableStock.expirationDate] ?? null,
          item[TableStock.quantityUnits] ?? null,
          item[TableStock.originalQuantityUnits] ?? null,
          item[TableStock.quantityWeight] ?? null,
          item[TableStock.originalQuantityWeight] ?? null,
          item[TableStock.priceAcquire]));
    }
    return list;
  }

  // @override
  // Future<List<Stock>> listStockProduct(int productId) async {
  //   final database = await getDatabase();
  //   final List<Map<String, dynamic>> result = await database.query(
  //       TableStock.tableName,
  //       where: '${TableStock.product} = ?',
  //       whereArgs: [productId]);
  //
  //   var list = <Stock>[];
  //
  //   for (final item in result) {
  //     list.add(Stock(
  //         item[TableStock.id],
  //         item[TableStock.product],
  //         item[TableStock.variants] ?? null,
  //         item[TableStock.batch],
  //         item[TableStock.manufacturingDate],
  //         item[TableStock.expirationDate] ?? null,
  //         item[TableStock.quantityUnits] ?? null,
  //         item[TableStock.originalQuantityUnits] ?? null,
  //         item[TableStock.quantityWeight] ?? null,
  //         item[TableStock.originalQuantityWeight] ?? null,
  //         item[TableStock.priceAcquire]));
  //   }
  //   return list;
  // }

  @override
  Future<bool> removeStock(Stock stock) async {
    final database = await getDatabase();

    try {
      database.delete(TableStock.tableName,
          where: '${TableStock.id} = ?',
          whereArgs: [stock.stockId]);
      return true;
    } catch(e){
      print('falha ao remover estoque');
      return false;
    }
  }

  @override
  Future<Stock> searchStockById(int id) async {
    final database = await getDatabase();
    final Map<String, dynamic> result = (await database.query(
        TableStock.tableName,
        where: '${TableStock.id} = ?',
        whereArgs: [id])) as Map<String, dynamic>;

      Stock s = Stock(
          result[TableStock.id],
          result[TableStock.product],
          result[TableStock.variants] ?? null,
          result[TableStock.batch],
          result[TableStock.manufacturingDate],
          result[TableStock.expirationDate] ?? null,
          result[TableStock.quantityUnits] ?? null,
          result[TableStock.originalQuantityUnits] ?? null,
          result[TableStock.quantityWeight] ?? null,
          result[TableStock.originalQuantityWeight] ?? null,
          result[TableStock.priceAcquire]);

    return s;
  }

  @override
  Future<bool> updateStock(Stock stock) async {
    final database = await getDatabase();
    var map = TableStock.toMap(stock);
    try {
      database.update(TableStock.tableName, map,
          where: '${TableStock.id} = ?',
          whereArgs: [stock.stockId]);
      return true;
    }catch(e){
      return false;
    }
  }
}
