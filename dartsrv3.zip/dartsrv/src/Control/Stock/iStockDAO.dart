import '../../model/stock.dart';

abstract interface class IStockDAO{
  Future<void> insertStock(Stock stock);

  Future<List<Stock>> listStock();

  Future<bool> updateStock(Stock stock);

  Future<bool> removeStock(Stock stock);

  Future<Stock> searchStockById(int id);

  Future<bool> cleanStock();
}