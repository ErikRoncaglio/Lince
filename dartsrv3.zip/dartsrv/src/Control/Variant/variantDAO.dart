import '../../model/variant.dart';
import '../Conexao/conection.dart';
import 'iVariantDAO.dart';

class VariantDAO implements IVariantDAO {
  @override
  Future<bool> cleanVariant() async {
    // TODO: implement cleanVariant
    throw UnimplementedError();
  }

  @override
  Future<void> insertVariant(Variant variant) async {
    final database = await getDatabase();
    final map = TableVariant.toMap(variant);

    await database.insert(TableVariant.tableName, map);

    return;
  }

  @override
  Future<List<Variant>> listVariant() async {
    final database = await getDatabase();
    final List<Map<String, dynamic>> result =
        await database.query(TableVariant.tableName);

    var list = <Variant>[];

    for (final item in result) {
      list.add(Variant(
          item[TableVariant.id],
          item[TableVariant.product],
          item[TableVariant.variantDescription],
          item[TableVariant.variantBarcode]));
    }
    return list;
  }

  @override
  Future<List<Variant>> listVariantProduct(int productId) async {
    final database = await getDatabase();
    final List<Map<String, dynamic>> result =
    await database.query(TableVariant.tableName,
    where: '${TableVariant.product} = ?',
    whereArgs: [productId]);

    var list = <Variant>[];

    for (final item in result) {
      list.add(Variant(
          item[TableVariant.id],
          item[TableVariant.product],
          item[TableVariant.variantDescription],
          item[TableVariant.variantBarcode]));
    }
    return list;
  }

  @override
  Future<bool> removeVariant(Variant variant) async {
   final database = await getDatabase();
   try {
     database.delete(TableVariant.tableName, where: '${TableVariant.id} = ?',
         whereArgs: [variant.variantId]);
     return true;
   }catch(e){
     return false;
   }
  }

  @override
  Future<Variant> searchVariantById(int id) async {
    // TODO: implement searchVariantById
    throw UnimplementedError();
  }

  @override
  Future<bool> updateVariant(Variant variant) async {
   final database = await getDatabase();

   var map= TableVariant.toMap(variant);

   try {
     database.update(TableVariant.tableName, map,
         where: '${TableVariant.id} = ?',
         whereArgs: [variant.variantId]);
     return true;
   }catch(e){
     return false;
   }
  }
}
