import '../../model/variant.dart';

abstract interface class IVariantDAO{
  Future<void> insertVariant(Variant stock);

  Future<List<Variant>> listVariant();

  Future<bool> updateVariant(Variant variant);

  Future<bool> removeVariant(Variant variant);

  Future<Variant> searchVariantById(int id);

  Future<bool> cleanVariant();
}