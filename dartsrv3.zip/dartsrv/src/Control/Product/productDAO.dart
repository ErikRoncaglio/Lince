import '../../model/product.dart';
import '../Conexao/conection.dart';
import 'iProductDAO.dart';

class ProductDAO implements IProductDAO {
  @override
  Future<bool> cleanProduct() async {
    // TODO: implement cleanProduct
    throw UnimplementedError();
  }

  @override
  Future<void> insertProduct(Product product) async {
    final database = await getDatabase();
    final map = TableProduct.toMap(product);

    await database.insert(TableProduct.tableName, map);

    return;
  }

  @override
  Future<List<Map<String, dynamic>>> listProduct() async {
    final database = await getDatabase();

    final List<Map<String, dynamic>> result = await database.query(
      TableProduct.tableName,
    );

    // var list = <Product>[];
    //
    // for (final item in result) {
    //   list.add(Product(
    //       item[TableProduct.id],
    //       item[TableProduct.name],
    //       item[TableProduct.additionalInformation] ?? null,
    //       item[TableProduct.barcode],
    //       item[TableProduct.brand],
    //       item[TableProduct.type],
    //       item[TableProduct.picture],
    //       item[TableProduct.price]));
    //
    // }
    return result;
  }

  @override
  Future<bool> removeProduct(Product product) async {
    final database = await getDatabase();

    try {
      database.delete(TableProduct.tableName,
          where: '${TableProduct.id} = ?',
          whereArgs: [product.productId]);
      return true;
    } catch(e){
      print('falha ao remover produto');
      return false;
    }
  }

  @override
  Future<Product> searchProductByName(String name) async {
    // TODO: implement searchProductByName
    throw UnimplementedError();
  }

  @override
  Future<bool> updateProduct(Product product) async {

    final database= await getDatabase();

    var map=TableProduct.toMap(product);

    try {
      database.update(TableProduct.tableName,
          map, where: '${TableProduct.id} = ?',
          whereArgs: [product.productId]);
    return true;
    }catch(e){
      return false;
    }

  }
}
