import '../../model/product.dart';

abstract interface class IProductDAO{
   Future<void> insertProduct(Product product);

   Future<List<Map<String, dynamic>>> listProduct();

   Future<bool> updateProduct(Product product);

   Future<bool> removeProduct(Product product);

   Future<Product> searchProductByName(String name);

   Future<bool> cleanProduct();
}