import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../../model/product.dart';
import '../../model/stock.dart';
import '../../model/variant.dart';

Future<Database> getDatabase() async {
  final path = join(
    await getDatabasesPath(),
    'mercearia.db',
  );

  return openDatabase(
    path,
    onCreate: (db, version) {
      db.execute(TableStock.createTable);
      db.execute(TableVariant.createTable);
      db.execute(TableProduct.createTable);
    },
    version: 1,
  );
}

class TableStock {
  // FK_Estoque_Produtos STRING NOT NULL,
  //     FOREIGN KEY (FK_Estoque_Produtos) REFERENCES Produtos (ProdutoId),
  //chave estrangeira que talvez seja usada

  static const String createTable =
      '''CREATE TABLE $tableName($id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
       $product INTEGER NOT NULL,
       $variants INTEGER NOT NULL,
        $batch TEXT NOT NULL, 
  $manufacturingDate TEXT NOT NULL,
   $expirationDate TEXT,
    $quantityUnits TEXT,
     $originalQuantityUnits TEXT,
      $quantityWeight TEXT,
       $originalQuantityWeight TEXT,
        $priceAcquire TEXT NOT NULL);''';

  static const String tableName = 'Estoque';
  static const String id = 'EstoqueId';
  static const String product = 'id_produto';
  static const String variants = 'id_variante';
  static const String batch = 'Lote';
  static const String manufacturingDate = 'Data de fabricação';
  static const String expirationDate = 'Data de validade';
  static const String quantityUnits = 'Quantidade em unidades';
  static const String originalQuantityUnits = 'Quantidade original de unidades';
  static const String quantityWeight = 'Quantidade por peso';
  static const String originalQuantityWeight = 'Quantidade original por peso';
  static const String priceAcquire = 'Preço de aquisição';

  static Map<String, dynamic> toMap(Stock stock) {
    final map = <String, dynamic>{};
    map[TableStock.id] = stock.stockId;
    map[TableStock.product] = stock.product;
    map[TableStock.batch] = stock.batch;
    map[TableStock.variants] = stock.variants;
    map[TableStock.expirationDate] = stock.expirationDate;
    map[TableStock.originalQuantityUnits] = stock.originalQuantityUnits;
    map[TableStock.originalQuantityWeight] = stock.originalQuantityWeight;
    map[TableStock.quantityWeight] = stock.quantityWeight;
    map[TableStock.quantityUnits] = stock.quantityUnits;
    map[TableStock.manufacturingDate] = stock.manufacturingDate;
    map[TableStock.priceAcquire] = stock.priceAcquire;

    return map;
  }
}

class TableVariant {
  static const String createTable =
      '''CREATE TABLE $tableName($id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
       $product INTEGER NOT NULL,
        $variantDescription TEXT NOT NULL,
         $variantBarcode TEXT NOT NULL);''';

  static const String tableName = 'Variantes';
  static const String id = 'VarianteId';
  static const String product = 'id_product';
  static const String variantDescription = 'Descrição';
  static const String variantBarcode = 'Código de Barras';

  static Map<String, dynamic> toMap(Variant variant) {
    final map = <String, dynamic>{};
    map[TableVariant.id] = variant.variantId;
    map[TableVariant.product] = variant.product;
    map[TableVariant.variantBarcode] = variant.variantBarcode;
    map[TableVariant.variantDescription] = variant.variantDescription;

    return map;
  }
}

class TableProduct {
  static const String createTable =
      '''CREATE TABLE $tableName($id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
       $name Text NOT NULL,
        $additionalInformation TEXT NOT NULL,
         $barcode TEXT NOT NULL,
          $brand TEXT NOT NULL,
          $type TEXT NOT NULL,
           $picture TEXT NOT NULL,
            $price TEXT NOT NULL);''';

  static const String tableName = 'Produtos';
  static const String id = 'ProdutoId';
  static const String name = 'Nome';
  static const String additionalInformation = 'Informações adicionais';
  static const String barcode = 'Código de barras';
  static const String brand = 'Marca';
  static const String type = 'Tipo';
  static const String picture = 'Imagem';
  static const String price = 'Preço de Aquisição';

  static Map<String, dynamic> toMap(Product product) {
    final map = <String, dynamic>{};
    map[TableProduct.id] = product.productId;
    map[TableProduct.name] = product.name;
    map[TableProduct.price] = product.price;
    map[TableProduct.picture] = product.picture;
    map[TableProduct.type] = product.type;
    map[TableProduct.brand] = product.brand;
    map[TableProduct.barcode] = product.barcode;
    map[TableProduct.additionalInformation] = product.additionalInformation;
    return map;
  }
}
