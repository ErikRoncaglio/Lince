// import 'dart:convert';
//
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/widgets.dart';
// import 'package:go_router/go_router.dart';
// import 'dart:async';
// import 'package:http/http.dart' as http;
//
// import '../screenSucess.dart';
// import 'product_model.dart';
//
// class ScreenListProduct extends StatefulWidget {
//   @override
//   State<StatefulWidget> createState() {
//     // TODO: implement createState
//     return ScreenListProductState();
//   }
// }
//
// class ScreenListProductState extends State<ScreenListProduct> {
//   late TextEditingController _controllerName;
//   late TextEditingController _controllerAdditionalInformation;
//   late TextEditingController _controllerBarcode;
//   late TextEditingController _controllerBrand;
//   late TextEditingController _controllerType;
//   late TextEditingController _controllerPicture;
//   late TextEditingController _controllerPrice;
//
//   int _Id = 0;
//   String _name = '';
//   String _additionalInformation = '';
//   String _barcode = '';
//   String _brand = '';
//   String _type = '';
//   String _picture = '';
//   double _price = 0;
//
//   String _validId = '';
//   String _validName = '';
//   String _validAdditionalInformation = '';
//   String _validBarcode = '';
//   String _validBrand = '';
//   String _validType = '';
//   String _validPicture = '';
//   String _validPrice = '';
//
//   Future<void> salvar() async {
//     // setState(() {
//     //   if (_controllerName.text.toString() != '') {
//     //     _name = _controllerName.text.toString();
//     //     _validName = '';
//     //   } else {
//     //     _validName = 'preencha o campo corretamente';
//     //   }
//     //
//     //   if (_controllerAdditionalInformation.text.toString() != '') {
//     //     _additionalInformation =
//     //         _controllerAdditionalInformation.text.toString();
//     //     _validAdditionalInformation = '';
//     //   } else {
//     //     _validAdditionalInformation = 'preencha o campo corretamente';
//     //   }
//     //   if (_controllerBrand.text.toString() != '') {
//     //     _brand = _controllerBrand.text.toString();
//     //     _validBrand = '';
//     //   } else {
//     //     _validBrand = 'preencha o campo corretamente';
//     //   }
//     //   if (_controllerPrice.text.toString() != '') {
//     //     _price = double.parse(_controllerPrice as String);
//     //     _validPrice = '';
//     //   } else {
//     //     _validPrice = 'preencha o campo corretamente';
//     //   }
//     //   if (_controllerBarcode.text.toString() != '') {
//     //     _barcode = _controllerBarcode.text.toString();
//     //     _validBarcode = '';
//     //   } else {
//     //     _validBarcode = 'preencha o campo corretamente';
//     //   }
//     //   if (_controllerType.text.toString() != '') {
//     //     _type = _controllerType.text.toString();
//     //     _validType = '';
//     //   } else {
//     //     _validType = 'preencha o campo corretamente';
//     //   }
//     // });
//
//     setState(() {
//       if (_name != '') {
//         _validName = '';
//       } else {
//         _validName = 'preencha o campo corretamente';
//       }
//
//       if (_additionalInformation != '') {
//         _validAdditionalInformation = '';
//       } else {
//         _validAdditionalInformation = 'preencha o campo corretamente';
//       }
//       if (_brand != '') {
//         _validBrand = '';
//       } else {
//         _validBrand = 'preencha o campo corretamente';
//       }
//       if (_price != 0) {
//         _validPrice = '';
//       } else {
//         _validPrice = 'preencha o campo corretamente';
//       }
//       if (_barcode != '') {
//         _validBarcode = '';
//       } else {
//         _validBarcode = 'preencha o campo corretamente';
//       }
//       if (_type != '') {
//         _validType = '';
//       } else {
//         _validType = 'preencha o campo corretamente';
//       }
//     });
//
//     if (_name != '' &&
//         _additionalInformation != '' &&
//         _barcode != '' &&
//         _brand != '' &&
//         _type != '' &&
//         _picture != '' &&
//         _price != 0) {
//       if (await submit() == true) {
//         return screenSucess(context);
//       } else {
//         return screenErro(context);
//       }
//     }
//   }
//
//   Future<bool> submit() async {
//     print("entrou no adicionar");
//     Product p = Product(_Id, _name, _additionalInformation, _barcode, _brand,
//         _type, _picture, _price);
//     var url = 'localhost:8080';
//     final response =
//         await http.post(Uri.http(url, '/product'), body: p.tojson());
//
//     if (response.statusCode == 200) {
//       print("foi");
//
//       return true;
//     }
//     return false;
//
//     //pegar os valores dos controler e usar para instanciar um objeto;
//     //inserir este objeto no banco;(fazer um post do objeto.fromjson), criar um novo end point no backend para isso
//     //validar se tudo foi feito com sucesso e exibir uma tela de confirmação
//     //atualizar a lista de produtos chamando o médoto para listar novamente
//     //fechar o pop up
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     _controllerName = TextEditingController();
//     _controllerAdditionalInformation = TextEditingController();
//     _controllerBarcode = TextEditingController();
//     _controllerBrand = TextEditingController();
//     _controllerType = TextEditingController();
//     _controllerPicture = TextEditingController();
//     _controllerPrice = TextEditingController();
//   }
//
//   @override
//   void dispose() {
//     _controllerName.dispose();
//     _controllerAdditionalInformation.dispose();
//     _controllerBarcode.dispose();
//     _controllerBrand.dispose();
//     _controllerType.dispose();
//     _controllerPicture.dispose();
//     _controllerPrice.dispose();
//
//     super.dispose();
//   }
//
//   Future openDialog() => showDialog(
//         context: context,
//         builder: (context)  => AlertDialog(
//           title: Text("Novo Produto"),
//           content: SizedBox(
//             height: 450,
//             width: 650,
//             child: Row(
//               crossAxisAlignment: CrossAxisAlignment.center,
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Column(
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   children: [
//                     SizedBox(
//                       width: 300,
//                       height: 70,
//                       child: TextField(
//                         onChanged: (value) => _name = value,
//                         autofocus: true,
//                         controller: _controllerName,
//                         decoration: InputDecoration(
//                           fillColor: Colors.white,
//                           labelText: 'Insira o nome:',
//                           focusColor: Colors.white,
//                           helperText: _validName,
//                           border: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(10),
//                             borderSide: BorderSide(color: Colors.black),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       width: 300,
//                       height: 70,
//                       child: TextField(
//                         onChanged: (value) => _type = value,
//                         autofocus: true,
//                         controller: _controllerType,
//                         decoration: InputDecoration(
//                           fillColor: Colors.white,
//                           labelText: 'Insira o tipo',
//                           focusColor: Colors.white,
//                           helperText: _validType,
//                           border: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(10),
//                             borderSide: BorderSide(color: Colors.black),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       width: 300,
//                       height: 70,
//                       child: TextField(
//                         onChanged: (value) => _barcode = value,
//                         autofocus: true,
//                         controller: _controllerBarcode,
//                         decoration: InputDecoration(
//                           fillColor: Colors.white,
//                           labelText: 'Insira o código de barras',
//                           focusColor: Colors.white,
//                           helperText: _validBarcode,
//                           border: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(10),
//                             borderSide: BorderSide(color: Colors.black),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       width: 300,
//                       height: 70,
//                       child: TextField(
//                         onChanged: (value) => _price = double.parse(value),
//                         keyboardType: TextInputType.number,
//                         autofocus: true,
//                         controller: _controllerPrice,
//                         decoration: InputDecoration(
//                           fillColor: Colors.white,
//                           labelText: 'Insira o preço:',
//                           focusColor: Colors.white,
//                           helperText: _validPrice,
//                           border: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(10),
//                             borderSide: BorderSide(color: Colors.black),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       width: 300,
//                       height: 70,
//                       child: TextField(
//                         onChanged: (value) => _brand = value,
//                         autofocus: true,
//                         controller: _controllerBrand,
//                         decoration: InputDecoration(
//                           fillColor: Colors.white,
//                           labelText: 'Insira a marca',
//                           focusColor: Colors.white,
//                           helperText: _validBrand,
//                           border: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(10),
//                             borderSide: BorderSide(color: Colors.black),
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       width: 300,
//                       height: 70,
//                       child: TextField(
//                         onChanged: (value) => _additionalInformation = value,
//                         autofocus: true,
//                         controller: _controllerAdditionalInformation,
//                         decoration: InputDecoration(
//                           fillColor: Colors.white,
//                           labelText: 'Informções adicionais:',
//                           focusColor: Colors.white,
//                           helperText: _validAdditionalInformation,
//                           border: OutlineInputBorder(
//                             borderRadius: BorderRadius.circular(10),
//                             borderSide: BorderSide(color: Colors.black),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//                 Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     Container(
//                       width: 300,
//                       height: 350,
//                       color: Colors.white54,
//                       child: Center(
//                         child: IconButton(
//                           icon: Icon(Icons.add_a_photo_outlined),
//                           onPressed: () {
//                             //chamar função de adicionar imagem
//                           },
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//           actions: [
//             ElevatedButton(
//                 style: ButtonStyle(
//                     backgroundColor: MaterialStatePropertyAll(Colors.green)),
//                 onPressed: salvar,
//                 child: const Text(
//                   "Salvar",
//                   style: TextStyle(color: Colors.white),
//                 ))
//           ],
//         ),
//       );
//
//   Future<List<Product>?> _getProduct() async {
//     Uri uri = Uri.parse('http://localhost:8080/products');
//     var response = await http.get(uri);
//     print(response.body);
//     var dados = json.decode(response.body) as List;
//     List<Product> products = [];
//     dados.forEach((element) {
//       Product p = Product(
//           element['productId'],
//           element['name'],
//           element['additionalInformation'],
//           element['barcode'],
//           element['brand'],
//           element['type'],
//           element['picture'],
//           element['price']);
//       products.add(p);
//     });
//     return products;
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     // TODO: implement build
//     return Scaffold(
//       body: Column(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         crossAxisAlignment: CrossAxisAlignment.center,
//         children: <Widget>[
//           Expanded(
//             child: FutureBuilder(
//               future: _getProduct(),
//               builder: (context, snapshot) {
//                 if (snapshot.connectionState == ConnectionState.waiting) {
//                   return const CircularProgressIndicator();
//                 } else {
//                   return ListView.builder(
//                       itemCount: snapshot.data?.length,
//                       itemBuilder: (context, i) {
//                         return ListTile(
//                           title: Text(snapshot.data![i].name.toString()),
//                           onTap: () {},
//                         );
//                       });
//                 }
//               },
//             ),
//           ),
//           Row(
//             crossAxisAlignment: CrossAxisAlignment.center,
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               Padding(
//                 padding: const EdgeInsets.all(12.0),
//                 child: FutureBuilder(
//                   future: openDialog(),
//                   builder: (context, snapshot) {
//                     ElevatedButton(
//                       onPressed: () => Navigator.pop(context),
//                       // onPressed: () => context.go("/Product"),
//                       child: const Text(
//                         'Adicionar Produto',
//                         style: TextStyle(color: Colors.white),
//                       ),
//                     );
//                   },
//                 ),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
// }

//exemplo pra validar uma resposta
// void main() async {
//   final future = http.get(Uri.http('local..', '/'));
//   future.then((response){
//     if(response.statusCode==200){
//       print("pag carregada com sucesso");
//     }
//     if(response.statusCode==301){
//       print("pag movida permanentemente");
//     }
//     if(response.statusCode==404){
//       print("pagina não encontrada");
//     }
//     if(response.statusCode==200){
//       print("erro interno no servidor");
//     }
//
//   } );
// future.catchError((onError)=>print('erro');
// future .whenComplete(()=> print('future completo!'))
// }

// final Pdao = ProductDAO();
//
// Future<void> insertP() async{
//   final p = Product(blablabla);
//
//   await Pdao.insertProduct(p);
//
//   await selectP();
//   notifyListeners();
// }
// usar para inserir produto no banco
//
//
// Future<void> selectP() async{
//   final list= await Pdao.listProduct();
//
//   listaProdutos.clear();
//   listaProdutos.addAll(list);
//
//   notifyListeners();
// }
// usar para listar produtos na tela (a lista listaProdutos sera criada na tela para usar no listView)(chamar o metodo de listar no construtor do provider para listar os itens assim que abrir o aplicativo)

//
// Future<bool> delete(Product p) async{
// await Pdao.delete(p);
// await selectP;
//
// notifyListeners();
// }

// Product? _pCurrent;
// void updateProduct(Product product) {
//   _controllerName.text = product.name ?? '';
//   _controllerType.text = product.type ?? '';
//   _controllerPrice.text = product.price ?? '';
//   _controllerPicture.text = product.picture ?? '';
//   _controllerAdditionalInformation.text = product.additionalInformation ?? '';
//   _controllerBrand.text = product.brand ?? '';
//   _controllerBarcode.text = product.barcode ?? '';
//   _controllerId.text = product.productId ?? '';
//
//   _pCurrent = Product(
//       product.productId,
//       product.name,
//       product.additionalInformation,
//       product.barcode,
//       product.brand,
//       product.type,
//       product.picture,
//       product.price);
//
//   //seta todos os elementos que ja estão armazenados no produto que sera atualizado(colocar os outros atributos de produto)
//
//   Future<void> updateP() async {
//     final editProduct = Product(
//         _pCurrent.productId,
//         _pCurrent.name,
//         _pCurrent?.additionalInformation,
//         _pCurrent.barcode,
//         _pCurrent.brand,
//         _pCurrent.type,
//         _pCurrent.picture,
//         _pCurrent.price);
//
//     await Pdao.updateProduct(editProduct);
//     _pCurrent = null;
//     _controllerName.clear();
//     _controllerType.clear();
//     _controllerPrice.clear();
//     _controllerPicture.clear();
//     _controllerAdditionalInformation.clear();
//     _controllerBrand.clear();
//     _controllerBarcode.clear();
//     _controllerId.clear();
//
//     await selectP();
//     //notifyListeners();
//   }
// }

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

import 'product_model.dart';

class ScreenListProduct extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Lista de produtos
          FutureBuilder<List<Product>>(
            future: _getProducts(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return CircularProgressIndicator();
              } else {
                if (snapshot.hasError) {
                  return Text('Erro ao carregar produtos: ${snapshot.error}');
                } else {
                  return Expanded(
                    child: ListView.builder(
                      itemCount: snapshot.data?.length ?? 0,
                      itemBuilder: (context, index) {
                        final product = snapshot.data![index];
                        return ListTile(
                            title: Text(product.name ?? 'Sem nome'),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Marca: ${product.brand}'),
                                Text(
                                    'Preço: R\$ ${product.price?.toStringAsFixed(2)}'),
                              ],
                            ));
                      },
                    ),
                  );
                }
              }
            },
          ),

          // Botão para adicionar produto
          ElevatedButton(
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => ProductDialog(),
              );
            },
            child: Text('Adicionar Produto'),
          ),
        ],
      ),
    );
  }
}

class ProductDialog extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text("Novo Produto"),
      content: ProductForm(),
    );
  }
}

class ProductForm extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final provider = ProductFormProvider();

    return ChangeNotifierProvider.value(
      value: provider,
      child: SizedBox(
        height: 450,
        width: 650,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            TextField(
              controller: provider.nameController,
              decoration: InputDecoration(
                labelText: 'Insira o nome:',
                errorText: provider.nameError,
              ),
            ),
            TextField(
              controller: provider.nameController,
              decoration: InputDecoration(
                labelText: 'Insira o nome:',
                errorText: provider.nameError,
              ),
            ),
            // Outros campos...
            ElevatedButton(
              onPressed: () async {
                if (provider.validateFields()) {
                  final success = await submitProduct(context, provider);
                  if (success) {
                    Navigator.of(context).pop(); // Fechar o diálogo
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Produto adicionado com sucesso')),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Erro ao adicionar produto')),
                    );
                  }
                }
              },
              child: Text('Salvar'),
            ),
          ],
        ),
      ),
    );
  }

  Future<bool> submitProduct(
      BuildContext context, ProductFormProvider provider) async {
    Product product = Product(
      name: provider.nameController.text,
      // Preencher com os dados dos outros campos
    );

    try {
      final response = await http.post(
        Uri.parse('http://localhost:8080/product'),
        body: product.toJson(),
      );

      if (response.statusCode == 200) {
        return true;
      }
    } catch (e) {
      print(e);
    }
    return false;
  }
}

class ProductFormProvider extends ChangeNotifier {
  late TextEditingController nameController;
  late TextEditingController brandController;
  late TextEditingController typeController;
  late TextEditingController barcodeController;
  late TextEditingController priceController;
  late TextEditingController additionalInformationController;

  String nameError = '';
  String brandError = '';
  String typeError = '';
  String barcodeError = '';
  String priceError = '';
  String additionalInformationError = '';

  ProductFormProvider() {
    nameController = TextEditingController();
    brandController = TextEditingController();
    typeController = TextEditingController();
    barcodeController = TextEditingController();
    priceController = TextEditingController();
    additionalInformationController = TextEditingController();
  }

  bool validateFields() {
    bool isValid = true;

    if (nameController.text.isEmpty) {
      nameError = 'Preencha o campo corretamente';
      isValid = false;
    } else {
      nameError = '';
    }
    if (brandController.text.isEmpty) {
      brandError = 'Preencha o campo corretamente';
      isValid = false;
    } else {
      brandError = '';
    }
    if (barcodeController.text.isEmpty) {
      barcodeError = 'Preencha o campo corretamente';
      isValid = false;
    } else {
      barcodeError = '';
    }
    if (priceController.text.isEmpty) {
      priceError = 'Preencha o campo corretamente';
      isValid = false;
    } else {
      priceError = '';
    }
    if (typeController.text.isEmpty) {
      typeError = 'Preencha o campo corretamente';
      isValid = false;
    } else {
      typeError = '';
    }
    if (additionalInformationController.text.isEmpty) {
      additionalInformationError = 'Preencha o campo corretamente';
      isValid = false;
    } else {
      additionalInformationError = '';
    }

    notifyListeners();
    return isValid;
  }
}

Future<List<Product>> _getProducts() async {
  final url = 'http://localhost:8080/products';
  final response = await http.get(Uri.parse(url));

  if (response.statusCode == 200) {
    final List<dynamic> data = jsonDecode(response.body);
    return data.map((json) => Product.fromJson(json)).toList();
  } else {
    throw Exception('Failed to load products');
  }
}

//talvez o update e delete

// class ScreenListProduct extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Column(
//         children: [
//           // Lista de produtos
//           FutureBuilder<List<Product>>(
//             future: _getProducts(),
//             builder: (context, snapshot) {
//               if (snapshot.connectionState == ConnectionState.waiting) {
//                 return CircularProgressIndicator();
//               } else {
//                 if (snapshot.hasError) {
//                   return Text('Erro ao carregar produtos: ${snapshot.error}');
//                 } else {
//                   return Expanded(
//                     child: ListView.builder(
//                       itemCount: snapshot.data?.length ?? 0,
//                       itemBuilder: (context, index) {
//                         final product = snapshot.data![index];
//                         return ListTile(
//                           title: Text(product.name ?? 'Sem nome'),
//                           subtitle: Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               Text('Marca: ${product.brand}'),
//                               Text(
//                                   'Preço: R\$ ${product.price?.toStringAsFixed(2)}'),
//                             ],
//                           ),
//                           onTap: () {
//                             _showProductOptions(context, product);
//                           },
//                         );
//                       },
//                     ),
//                   );
//                 }
//               }
//             },
//           ),
//         ],
//       ),
//     );
//   }
//
//   void _showProductOptions(BuildContext context, Product product) {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: Text('Opções do Produto'),
//         content: Column(
//           mainAxisSize: MainAxisSize.min,
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             ElevatedButton(
//               onPressed: () {
//                 Navigator.pop(context); // Fechar o diálogo
//                 _showUpdateProductDialog(context, product);
//               },
//               child: Text('Atualizar Produto'),
//             ),
//             ElevatedButton(
//               onPressed: () {
//                 Navigator.pop(context); // Fechar o diálogo
//                 _deleteProduct(context, product);
//               },
//               child: Text('Excluir Produto'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   void _showUpdateProductDialog(BuildContext context, Product product) {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: Text("Atualizar Produto"),
//         content: ProductForm(product: product),
//       ),
//     );
//   }
//
//   void _deleteProduct(BuildContext context, Product product) async {
//     try {
//       final response = await http.delete(
//         Uri.parse('http://localhost:8080/product/${product.id}'),
//       );
//       if (response.statusCode == 200) {
//         ScaffoldMessenger.of(context).showSnackBar(
//           SnackBar(content: Text('Produto excluído com sucesso')),
//         );
//         // Atualizar a lista de produtos após a exclusão
//         Provider.of<ProductListProvider>(context, listen: false).refresh();
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(
//           SnackBar(content: Text('Erro ao excluir o produto')),
//         );
//       }
//     } catch (e) {
//       print('Erro ao excluir produto: $e');
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Erro ao excluir o produto')),
//       );
//     }
//   }
// }
//
// class ProductForm extends StatelessWidget {
//   final Product? product;
//
//   ProductForm({this.product});
//
//   @override
//   Widget build(BuildContext context) {
//     final provider = ProductFormProvider(product: product);
//
//     return ChangeNotifierProvider.value(
//       value: provider,
//       child: SizedBox(
//         height: 450,
//         width: 650,
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.center,
//           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//           children: [
//             TextField(
//               controller: provider.nameController,
//               decoration: InputDecoration(
//                 labelText: 'Insira o nome:',
//                 errorText: provider.nameError,
//               ),
//             ),
//             // Adicione outros campos conforme necessário...
//             ElevatedButton(
//               onPressed: () async {
//                 if (provider.validateFields()) {
//                   final success = await submitProduct(context, provider);
//                   if (success) {
//                     Navigator.of(context).pop(); // Fechar o diálogo
//                     ScaffoldMessenger.of(context).showSnackBar(
//                       SnackBar(content: Text('Produto atualizado com sucesso')),
//                     );
//                     // Atualizar a lista de produtos após a atualização
//                     Provider.of<ProductListProvider>(context, listen: false).refresh();
//                   } else {
//                     ScaffoldMessenger.of(context).showSnackBar(
//                       SnackBar(content: Text('Erro ao atualizar o produto')),
//                     );
//                   }
//                 }
//               },
//               child: Text('Salvar'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
// // Função submitProduct() para atualização do produto...
// }
