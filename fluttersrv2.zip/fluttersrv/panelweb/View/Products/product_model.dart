class Product {
  int? productId;
  String? name;
  String? additionalInformation;
  String? barcode;
  String? brand;
  String? type;
  String? picture;
  double? price;

  Product({
    this.productId,
    this.name,
    this.additionalInformation,
    this.barcode,
    this.brand,
    this.type,
    this.picture,
    this.price,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      productId: json['productId'],
      name: json['name'],
      additionalInformation: json['additionalInformation'],
      barcode: json['barcode'],
      brand: json['brand'],
      type: json['type'],
      picture: json['picture'],
      price: json['price'],
    );
  }

  Map<String, dynamic> toJson() => {
        'productId': this.productId,
        'name': this.name,
        'additionalInformation': this.additionalInformation,
        'barcode': this.barcode,
        'brand': this.brand,
        'type': this.type,
        'picture': this.picture,
        'price': this.price,
      };
}

class Products {
  final List products;
  Products(this.products);
}
