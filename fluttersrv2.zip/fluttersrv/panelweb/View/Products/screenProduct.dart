import 'package:flutter/material.dart';

class ScreenProduct extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return ScreenProductState();
  }
}

class ScreenProductState extends State<ScreenProduct> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container();
  }
}
