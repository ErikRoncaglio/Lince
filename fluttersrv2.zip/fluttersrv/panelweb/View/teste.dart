import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Imagens',
      home: Formas(title: 'testeAnimacao'),
    );
  }
}

class Formas extends StatefulWidget {
  final String title;
  Formas({Key? key, required this.title}) : super(key: key);

  @override
  _FormasState createState() => _FormasState();
}

class _FormasState extends State<Formas> {
  Color cor = Colors.blue;
  double altura = 100;
  double largura = 400;

  Color cor2 = Colors.blue;
  double altura2 = 100;
  double largura2 = 350;

  Color cor3 = Colors.blue;
  double altura3 = 100;
  double largura3 = 300;

  Color cor4 = Colors.blue;
  double altura4 = 100;
  double largura4 = 250;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cone'),
      ),
      body: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              MouseRegion(
                child:
                    TrapezoidIcon(color: cor, height: altura, width: largura),
                onHover: (event) {
                  setState(() {
                    cor = Colors.blueGrey;
                    largura = 500;
                  });
                },
                onExit: (event) {
                  setState(() {
                    cor = Colors.blue;
                    largura = 400;
                  });
                },
              ),
              MouseRegion(
                child: TrapezoidIcon(
                    color: cor2, height: altura2, width: largura2),
                onHover: (event) {
                  setState(() {
                    cor2 = Colors.blueGrey;
                    largura2 = 450;
                  });
                },
                onExit: (event) {
                  setState(() {
                    cor2 = Colors.blue;
                    largura2 = 350;
                  });
                },
              ),
              MouseRegion(
                child: TrapezoidIcon(
                    color: cor3, height: altura3, width: largura3),
                onHover: (event) {
                  setState(() {
                    cor3 = Colors.blueGrey;
                    largura3 = 400;
                  });
                },
                onExit: (event) {
                  setState(() {
                    cor3 = Colors.blue;
                    largura3 = 300;
                  });
                },
              ),
              MouseRegion(
                child: TrapezoidIcon(
                    color: cor4, height: altura4, width: largura4),
                onHover: (event) {
                  setState(() {
                    cor4 = Colors.blueGrey;
                    largura4 = 350;
                  });
                },
                onExit: (event) {
                  setState(() {
                    cor4 = Colors.blue;
                    largura4 = 250;
                  });
                },
              ),
            ],
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                color: Colors.cyan,
                width: 100,
                height: 50,
                margin: EdgeInsets.all(10.00),
              ),
            ],
          )
        ],
      ),
    );
  }
}

class TrapezoidIcon extends StatelessWidget {
  final double width;
  final double height;
  final Color color;

  const TrapezoidIcon({
    Key? key,
    required this.width,
    required this.height,
    required this.color,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(width, height),
      painter: TrapezoidPainter(color),
    );
  }
}

class TrapezoidPainter extends CustomPainter {
  final Color color;

  TrapezoidPainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color;

    final double borderRadius = 10;

    final path = Path()
      ..moveTo(size.width * 0.2, size.height) // Ponto inferior esquerdo
      ..lineTo(size.width * 0.8, size.height) // Ponto inferior direito
      ..lineTo(size.width, borderRadius * 2) // Ponto superior direito
      ..lineTo(0, borderRadius * 2) // Ponto superior esquerdo
      ..close(); // Fecha o caminho

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
