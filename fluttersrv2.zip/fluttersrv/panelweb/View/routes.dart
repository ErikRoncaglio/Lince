import 'package:go_router/go_router.dart';

import 'Login/screenLogin.dart';
import 'Products/screenListProduct.dart';
import 'Products/screenProduct.dart';
import 'Stocks/screenStock.dart';
import 'Variants/screenVariant.dart';
import 'screenHome.dart';

void main() async {
  runApp(const MyApp());
}

// Definindo a chave para o Navigator do ShellRoute
final GlobalKey<NavigatorState> _shellNavigatorKey =
    GlobalKey<NavigatorState>();

// GoRouter configuration
final _router = GoRouter(
  initialLocation: '/Home',
  routes: [
    ShellRoute(
      navigatorKey: _shellNavigatorKey,
      builder: (context, state, child) {
        return Scaffold(
          appBar: AppBar(
            title: Text('R.R Store'),
            // Adicionando um ícone de menu à AppBar para abrir o Drawer
            leading: IconButton(
              icon: Icon(Icons.menu),
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
            ),
          ),
          drawer: Drawer(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                DrawerHeader(
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor,
                  ),
                  child: Text(
                    'Opções',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                    ),
                  ),
                ),
                ListTile(
                  title: Text('Home'),
                  onTap: () {
                    GoRouter.of(context).go('/Home');
                    Navigator.pop(context);
                  },
                ),
                ListTile(
                  title: Text('Produtos'),
                  onTap: () {
                    GoRouter.of(context).go('/Products');
                    Navigator.pop(context);
                  },
                ),
                // Adicione mais ListTile para outras telas se necessário
              ],
            ),
          ),
          body: child,
        );
      },
      routes: [
        GoRoute(
          path: '/Login',
          builder: (context, state) => ScreenLogin(),
        ),
        GoRoute(
          path: '/Home',
          builder: (context, state) => ScreenHome(),
        ),
        GoRoute(
          path: '/Products',
          builder: (context, state) => ScreenListProduct(),
        ),
        GoRoute(
          path: '/Product',
          builder: (context, state) => ScreenProduct(),
        ),
      ],
    ),
  ],
);

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      // Adicionando um banner de debug apenas em modo de desenvolvimento
      debugShowCheckedModeBanner: false,
      routerDelegate: _router.routerDelegate,
      routeInformationParser: _router.routeInformationParser,
      theme: ThemeData(
        // Definindo a paleta de cores
        colorScheme: const ColorScheme(
          background: Color.fromRGBO(223, 217, 202, 1),
          brightness: Brightness.light,
          primary: Color.fromRGBO(209, 74, 59, 1),
          onPrimary: Color.fromRGBO(255, 255, 255, 1),
          secondary: Color.fromRGBO(80, 52, 49, 1),
          onSecondary: Color.fromRGBO(255, 255, 255, 1),
          error: Color.fromRGBO(230, 136, 4, 1),
          onError: Color.fromRGBO(255, 255, 255, 1),
          onBackground: Color.fromRGBO(92, 140, 69, 1),
          surface: Color.fromRGBO(92, 140, 69, 1),
          onSurface: Color.fromRGBO(255, 255, 255, 1),
        ),
      ),
      title: 'R.R Store',
    );
  }
}

// import 'package:flutter/material.dart';
// import 'package:go_router/go_router.dart';
//
// import 'Login/screenLogin.dart';
// import 'Products/screenListProduct.dart';
// import 'Products/screenProduct.dart';
// import 'Stocks/screenStock.dart';
// import 'Variants/screenVariant.dart';
// import 'screenHome.dart';
//
// void main() async{
//   runApp(const MyApp());
// }
//
// // GoRouter configuration
// final _router = GoRouter(
//   initialLocation: '/Products',
//   // redirect: (context, state) {
//   //   final isLogged = false;
//
//   // if (state.path != '/') {
//   //   // a.....
//   //   if (!isLogged) {
//   //     return '/Login';
//   //   }
//   //
//   //     if (userRequiresOk) {
//   //       return '/requestOk';
//   //     }
//   //
//   //     return null;
//   //   }
//   // },
//   routes: [
//     GoRoute(
//       path: '/Login',
//       builder: (context, state) => ScreenLogin(),
//     ),
//     GoRoute(
//       path: '/Home',
//       builder: (context, state) => ScreenHome(),
//     ),GoRoute(
//       path: '/Products',
//       builder: (context, state) => ScreenListProduct(),
//     ),
//     GoRoute(
//       path: '/Product',
//       builder: (context, state) => ScreenProduct(),
//     ),
//
// //     ShellRoute(
// //         builder: (BuildContext context, GoRouterState state, Widget child) {
// //           return const Scaffold(
// //             drawer: Drawer(
// //               width: 50,
// //               child: Column(
// //                 mainAxisAlignment: MainAxisAlignment.start,
// //                 crossAxisAlignment: CrossAxisAlignment.center,
// //                 children: [
// //                   Row(
// //                     children: [Text('Product')],
// //                   ),
// //                   Divider(
// //                     color: Colors.black,
// //                     thickness: 1,
// //                     indent: 5,
// //                     endIndent: 5,
// //                     height: 10,
// //                   ),
// //                   Row(
// //                     children: [Text('Variant')],
// //                   ),
// //                   Divider(  color: Colors.black,
// //                     thickness: 1,
// //                     indent: 5,
// //                     endIndent: 5,
// //                     height: 10,),
// //                   Row(
// //                     children: [Text('Stock')],
// //                   ),
// //                   Divider(  color: Colors.black,
// //                     thickness: 1,
// //                     indent: 5,
// //                     endIndent: 5,
// //                     height: 10,),
// //                   Row(
// //                     children: [Text('Config')],
// //                   )
// //                 ],
// //               ),
// //             ),
// //             /* ... */
// //           );
// //         },
// //         routes: <RouteBase>[
// //           GoRoute(
// //               path: '/Home',
// //               builder: (context, state) => ScreenHome(),
// //               routes: [
// //                 GoRoute(
// //                     path: '/Product',
// //                     builder: (context, state) => ScreenProduct(),
// //                     routes: [
// //                       GoRoute(
// //                         path: '/detailsProduct',
// // //    builder: (context, state) => ScreenProductDetails(),
// //                       ),
// //                     ]),
// //                 GoRoute(
// //                     path: '/Variant',
// //                     builder: (context, state) => ScreenVariant(),
// //                     routes: [
// //                       GoRoute(
// //                         path: '/detailsVariant',
// // //     builder: (context, state) => ScreenVariantDetails(),
// //                       ),
// //                     ]),
// //                 GoRoute(
// //                     path: '/Stock',
// //                     builder: (context, state) => ScreenStock(),
// //                     routes: [
// //                       GoRoute(
// //                         path: '/detailsStock',
// // //    builder: (context, state) => ScreenStockDetails(),
// //                       ),
// //                     ]),
// //                 GoRoute(
// //                   path: '/Config',
// // //  builder: (context, state) => ScreenConfig(),
// //                 ),
// //               ]),
// //         ]),
//   ],
// );
//
// class MyApp extends StatelessWidget {
//   const MyApp({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp.router(
//       routerConfig: _router,
//       theme: ThemeData(
//         colorScheme: const ColorScheme(
//           background: Color.fromRGBO(223, 217, 202, 1),
//           brightness: Brightness.light,
//           primary: Color.fromRGBO(209, 74, 59, 1),
//           onPrimary: Color.fromRGBO(209, 74, 59, 1),
//           secondary: Color.fromRGBO(80, 52, 49, 1),
//           onSecondary: Color.fromRGBO(80, 52, 49, 1),
//           error: Color.fromRGBO(230, 136, 4, 1),
//           onError: Color.fromRGBO(230, 136, 4, 1),
//           onBackground: Color.fromRGBO(92, 140, 69, 1),
//           surface: Color.fromRGBO(92, 140, 69, 1),
//           onSurface: Color.fromRGBO(92, 140, 69, 1),
//         ),
//       ),
//       title: 'R.R Store',
//     );
//   }
// }
