import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

screenSucess(context) => showDialog(
    context: context,
    builder: (context) => Column(
          children: [
            Container(
              height: 150,
              width: 250,
              child: Center(
                child: Text('Sucesso'),
              ),
            ),
            ElevatedButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Confirmar'))
          ],
        ));

screenErro(context) => showDialog(
    context: context,
    builder: (context) => Column(
          children: [
            Container(
              height: 150,
              width: 250,
              child: Center(
                child: Text(
                  'Erro',
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Confirmar'),
              style: ButtonStyle(
                  backgroundColor: MaterialStatePropertyAll(Colors.red)),
            )
          ],
        ));
