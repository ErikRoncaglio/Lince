import 'package:flutter/material.dart';

class ScreenVariant extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return ScreenVariantState();
  }
}

class ScreenVariantState extends State<ScreenVariant> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      body: Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [Text("olá")],
        ),
      ),
    );
    ;
  }
}
