import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class ScreenHome extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return ScreenHomeState();
  }
}

class ScreenHomeState extends State<ScreenHome> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
      ),
      body: Column(
        verticalDirection: VerticalDirection.down,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text("Bem vindo"),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                  child: ElevatedButton(
                child: Text('tela de login'),
                onPressed: () => context.go('/Product'),
              )),
            ],
          ),
          // Row(
          //   crossAxisAlignment: CrossAxisAlignment.center,
          //   mainAxisAlignment: MainAxisAlignment.center,
          //   children: [
          //     Expanded(
          //       child: Container(
          //         padding: EdgeInsets.all(12),
          //         color: Colors.deepOrangeAccent,
          //       ),
          //     ),
          //   ],
          // ),
          // Row(
          //   crossAxisAlignment: CrossAxisAlignment.center,
          //   mainAxisAlignment: MainAxisAlignment.center,
          //   children: [
          //     Expanded(
          //       child: Container(
          //         padding: EdgeInsets.all(12),
          //         color: Colors.deepOrangeAccent,
          //       ),
          //     ),
          //   ],
          // ),
          // Row(
          //   crossAxisAlignment: CrossAxisAlignment.center,
          //   mainAxisAlignment: MainAxisAlignment.center,
          //   children: [
          //     Expanded(
          //       child: Container(
          //         padding: EdgeInsets.all(12),
          //         color: Colors.deepOrangeAccent,
          //       ),
          //     ),
          //   ],
          // ),
        ],
      ),
    );
  }
}
