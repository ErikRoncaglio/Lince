import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:http/http.dart' as http;

class LoginRequest {
  LoginRequest(this.login, this.password);

  final String login;
  final String password;

  Map<String, dynamic> toJson() => {
        "login": this.login,
        "password": this.password,
      };

  LoginRequest.fromJson(Map<String, dynamic> json)
      : login = json['name'] as String,
        password = json['email'] as String;
}

class ScreenLogin extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return ScreenLoginState();
  }
}

class ScreenLoginState extends State<ScreenLogin> {
  String? _validSenha;
  String? _validUsuario;
  late String token;

  final _controllerUsuario = TextEditingController();
  final _controllerSenha = TextEditingController();
  late String _usuario;
  late String _senha;

  bool _isLogged = false;
  // void handleGetUser() async{
  //   final response = await get
  // }

  Future<String> tryLogin(String login, String password) async {
    // final url = Uri.http('localhost:8080/', 'login');
    // var response = await client.get(uri);
    // final url = Uri.parse('http://localhost:8080/login');
    var url = 'localhost:8080';
    final response = await http.post(
      Uri.http(url, '/login'),
      body: jsonEncode({
        'login': login,
        'password': password,
      }),
    );

    print(response);
    if (response.statusCode == 403) {
      return '';
    }
    final responseData = jsonDecode(response.body);
    final token = responseData['token'];

    return token;
  }

  Future<bool> tryAuthenticatedUser(String token) async {
    print('c-------------------------------');
    var url = 'localhost:8080';
    final response = await http.get(
      Uri.http(url, 'api/user'),
      headers: {
        'Authorization': 'Bearer $token',
      },
    );
    print(response.body);
    if (response.statusCode == 200) {
      return true;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Column(
        children: [
          const Padding(
            padding: EdgeInsets.only(left: 30, bottom: 10, top: 40),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  'Olá, Seja bem-vindo a',
                  style: TextStyle(fontSize: 20),
                ),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.only(left: 30, bottom: 10, top: 10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  'R.R Store',
                  style: TextStyle(
                      color: Colors.redAccent,
                      fontSize: 35,
                      fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 70,
            width: double.infinity,
          ),
          Padding(
            padding:
                const EdgeInsets.only(left: 40, bottom: 15, top: 40, right: 40),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Usuário: ',
                  style: TextStyle(color: Colors.black, fontSize: 18),
                ),
                Expanded(
                  flex: 1,
                  child: TextField(
                    onChanged: (value) => setState(
                      () {
                        _validUsuario = '';
                      },
                    ),
                    controller: _controllerUsuario,
                    decoration: InputDecoration(
                      helperText: _validUsuario,
                      label: const Text(
                        'Insira seu usuário',
                        style: TextStyle(color: Colors.grey),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: const BorderSide(color: Colors.black),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding:
                const EdgeInsets.only(left: 40, bottom: 30, top: 10, right: 40),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Senha: ',
                  style: TextStyle(color: Colors.black, fontSize: 18),
                ),
                Expanded(
                  flex: 1,
                  child: TextField(
                    onChanged: (value) => setState(
                      () {
                        _validSenha = '';
                      },
                    ),
                    controller: _controllerSenha,
                    obscureText: true,
                    decoration: InputDecoration(
                      helperText: _validSenha,
                      label: const Text(
                        'Insira sua senha',
                        style: TextStyle(color: Colors.grey),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: const BorderSide(color: Colors.black),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(25.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () async {
                    setState(() {
                      _usuario = _controllerUsuario.text;
                      _senha = _controllerSenha.text;
                    });
                    if (_senha.isNotEmpty && _usuario.isNotEmpty) {
                      var u = LoginRequest(_usuario, _senha);

                      token = await tryLogin(u.login, u.password);

                      if (token != '') {
                        if (await tryAuthenticatedUser(token) == true) {
                          context.go('/Home');
                        } else {
                          print('credenciais inválidas');
                        }
                      } else {
                        print('token inválido');
                      }
                    } else if (_senha.isEmpty) {
                      setState(() {
                        _validSenha = 'Insira a senha corretamente!';
                      });
                    } else if (_usuario.isEmpty) {
                      setState(() {
                        _validUsuario = 'Insira o usuário corretamente!';
                      });
                    }
                  },
                  child: const Text(
                    'Entrar',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
